"""
=============================================================================
DATA LOADER - Carregamento de Dados Financeiros
=============================================================================
Módulo responsável por carregar e processar os dados históricos dos ativos.

Ativos suportados:
- IBOVESPA (índice principal)
- Dólar (USD/BRL)
- Petróleo Brent
- Taxa Selic
- PETR3 (Petrobras)
- VALE3 (Vale)

Autor: Gustavo
Data: 11 de Janeiro de 2026
=============================================================================
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional


def parse_brazilian_number(value) -> float:
    """
    Converte número no formato brasileiro para float.
    
    Exemplos:
        "1.234,56" -> 1234.56
        "1,5B" -> 1500000000.0
        "2,3M" -> 2300000.0
        "-0,5%" -> -0.5
    
    Args:
        value: Valor a ser convertido (string ou número)
    
    Returns:
        float: Valor numérico
    """
    if pd.isna(value):
        return np.nan
    if isinstance(value, (int, float)):
        return float(value)
    
    value = str(value).strip()
    
    # Tratar sufixos de volume
    multiplier = 1
    if value.endswith('B'):
        multiplier = 1e9
        value = value[:-1]
    elif value.endswith('M'):
        multiplier = 1e6
        value = value[:-1]
    elif value.endswith('K'):
        multiplier = 1e3
        value = value[:-1]
    
    # Remover pontos de milhar e trocar vírgula por ponto
    value = value.replace('.', '').replace(',', '.')
    
    # Remover % se existir
    value = value.replace('%', '')
    
    try:
        return float(value) * multiplier
    except:
        return np.nan


def load_csv_data(file_path: Path, asset_name: str) -> pd.DataFrame:
    """
    Carrega dados de um arquivo CSV no formato brasileiro.
    
    Args:
        file_path: Caminho para o arquivo CSV
        asset_name: Nome do ativo (ex: 'IBOV', 'DOLAR')
    
    Returns:
        DataFrame com dados processados
    """
    print(f"  -> Carregando {asset_name}...")
    
    try:
        df = pd.read_csv(file_path, encoding='utf-8')
    except:
        df = pd.read_csv(file_path, encoding='latin-1')
    
    # Padronizar nome da coluna de data
    date_cols = ['Data', 'data', 'DATE', 'Date', 'Lançamento']
    for col in date_cols:
        if col in df.columns:
            df = df.rename(columns={col: 'Data'})
            break
    
    if 'Data' not in df.columns:
        print(f"     Coluna de data não encontrada em {asset_name}")
        return pd.DataFrame({'Data': []})
    
    # Converter data
    df['Data'] = pd.to_datetime(df['Data'], format='%d.%m.%Y', errors='coerce')
    
    # Tratar arquivo Selic (formato diferente)
    if asset_name == 'SELIC':
        if 'Atual' in df.columns:
            df['Último'] = df['Atual'].apply(parse_brazilian_number)
        df = df[['Data', 'Último']].copy()
        df = df.rename(columns={'Último': f'{asset_name}_Ultimo'})
        df = df.dropna()
        df = df.sort_values('Data').reset_index(drop=True)
        print(f"    [OK] {len(df)} registros carregados")
        return df
    
    # Converter colunas numéricas
    numeric_cols = ['Último', 'Abertura', 'Máxima', 'Mínima', 'Vol.', 'Var%']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = df[col].apply(parse_brazilian_number)
    
    # Renomear colunas
    rename_map = {
        'Último': f'{asset_name}_Ultimo',
        'Abertura': f'{asset_name}_Abertura',
        'Máxima': f'{asset_name}_Maxima',
        'Mínima': f'{asset_name}_Minima',
        'Vol.': f'{asset_name}_Volume',
        'Var%': f'{asset_name}_Var'
    }
    df = df.rename(columns=rename_map)
    
    # Manter apenas colunas relevantes
    cols_to_keep = ['Data'] + [c for c in df.columns if c.startswith(asset_name)]
    df = df[[c for c in cols_to_keep if c in df.columns]]
    
    # Ordenar por data
    df = df.sort_values('Data').reset_index(drop=True)
    
    print(f"    [OK] {len(df)} registros carregados")
    return df


def load_all_data(data_path: str = None) -> pd.DataFrame:
    """
    Carrega e mescla todos os dados dos ativos.
    
    Args:
        data_path: Caminho para a pasta de dados (se None, usa pasta relativa ao script)
    
    Returns:
        DataFrame com todos os ativos mesclados
    """
    print("\n" + "="*60)
    print(" CARREGANDO DADOS")
    print("="*60)
    
    # Se não especificado, usar pasta 'dados' relativa ao diretório do projeto
    if data_path is None:
        # Obter diretório do script atual
        script_dir = Path(__file__).parent.parent
        data_path = script_dir / "dados"
    else:
        data_path = Path(data_path)
    
    # Arquivos de dados
    data_files = {
        'IBOV': data_path / "Dados Históricos - Ibovespa.csv",
        'DOLAR': data_path / "USD_BRL Dados Históricos.csv",
        'PETROLEO': data_path / "Dados Históricos - Petróleo Brent Futuros.csv",
        'SELIC': data_path / "Dados Históricos Selic.csv",
        'PETR3': data_path / "PETR3 Dados Históricos.csv",
        'VALE3': data_path / "VALE3 Dados Históricos.csv",
    }
    
    # Carregar IBOVESPA (principal)
    df_main = load_csv_data(data_files['IBOV'], 'IBOV')
    
    # Carregar e mesclar outros ativos
    for asset, path in data_files.items():
        if asset == 'IBOV':
            continue
        if path.exists():
            df_asset = load_csv_data(path, asset)
            if len(df_asset) > 0:
                df_main = df_main.merge(df_asset, on='Data', how='left')
    
    # Forward fill para valores faltantes (especialmente Selic)
    df_main = df_main.ffill().bfill()
    
    # Remover linhas com NaN
    df_main = df_main.dropna()
    
    print(f"\n[OK] Total de registros: {len(df_main)}")
    print(f"[OK] Período: {df_main['Data'].min().strftime('%d/%m/%Y')} a {df_main['Data'].max().strftime('%d/%m/%Y')}")
    print(f"[OK] Colunas: {len(df_main.columns)}")
    
    return df_main
