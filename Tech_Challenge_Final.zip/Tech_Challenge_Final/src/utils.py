"""
=============================================================================
UTILS - Funções Utilitárias
=============================================================================
Funções auxiliares para o projeto de previsão do IBOVESPA.

Autor: Gustavo
Data: 11 de Janeiro de 2026
=============================================================================
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
import pickle
from pathlib import Path


def split_train_test(X: np.ndarray, y: np.ndarray, 
                     test_days: int = 30,
                     train_days: int = 1000,
                     offset: int = 0) -> tuple:
    """
    Divide dados em treino e teste.
    
    Args:
        X: Features
        y: Target
        test_days: Número de dias para teste
        train_days: Número de dias para treino
        offset: Offset do final do dataset
    
    Returns:
        X_train, y_train, X_test, y_test
    """
    total = len(X)
    
    test_end = total - offset
    test_start = test_end - test_days
    train_end = test_start
    train_start = max(0, train_end - train_days)
    
    X_train = X[train_start:train_end]
    y_train = y[train_start:train_end]
    X_test = X[test_start:test_end]
    y_test = y[test_start:test_end]
    
    return X_train, y_train, X_test, y_test


def normalize_data(X_train: np.ndarray, X_test: np.ndarray) -> tuple:
    """
    Normaliza os dados usando StandardScaler.
    
    Args:
        X_train: Features de treino
        X_test: Features de teste
    
    Returns:
        X_train_scaled, X_test_scaled, scaler
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, scaler


def print_metrics(metrics: dict):
    """
    Imprime métricas de avaliação formatadas.
    
    Args:
        metrics: Dicionário com métricas
    """
    print(f"\n MÉTRICAS DE AVALIAÇÃO:")
    print(f"   Acurácia: {metrics['accuracy']*100:.2f}%")
    print(f"   Precision: {metrics['precision']*100:.2f}%")
    print(f"   Recall: {metrics['recall']*100:.2f}%")
    print(f"   F1-Score: {metrics['f1']*100:.2f}%")
    print(f"   Threshold: {metrics['threshold']}")
    
    if 'y_true' in metrics and 'y_pred' in metrics:
        cm = confusion_matrix(metrics['y_true'], metrics['y_pred'])
        print(f"\n Matriz de Confusão:")
        print(f"   [[TN={cm[0,0]:2d}  FP={cm[0,1]:2d}]")
        print(f"    [FN={cm[1,0]:2d}  TP={cm[1,1]:2d}]]")


def save_model(model, scaler, config: dict, path: str = None):
    """
    Salva modelo, scaler e configurações.
    
    Args:
        model: Modelo Keras
        scaler: StandardScaler
        config: Configurações
        path: Caminho para salvar (se None, usa pasta relativa ao script)
    """
    if path is None:
        # Usar pasta 'models' relativa ao diretório do projeto
        script_dir = Path(__file__).parent.parent
        path = script_dir / "models"
    else:
        path = Path(path)
    
    path.mkdir(exist_ok=True)
    
    model.save(path / "modelo_gru.keras")
    
    with open(path / "scaler.pkl", 'wb') as f:
        pickle.dump(scaler, f)
    
    with open(path / "config.pkl", 'wb') as f:
        pickle.dump(config, f)
    
    print(f"\n Modelo salvo em {path}/")


def load_model(path: str = None):
    """
    Carrega modelo, scaler e configurações.
    
    Args:
        path: Caminho dos arquivos (se None, usa pasta relativa ao script)
    
    Returns:
        model, scaler, config
    """
    from tensorflow.keras.models import load_model as keras_load
    
    if path is None:
        script_dir = Path(__file__).parent.parent
        path = script_dir / "models"
    else:
        path = Path(path)
    
    model = keras_load(path / "modelo_gru.keras")
    
    with open(path / "scaler.pkl", 'rb') as f:
        scaler = pickle.load(f)
    
    with open(path / "config.pkl", 'rb') as f:
        config = pickle.load(f)
    
    return model, scaler, config
