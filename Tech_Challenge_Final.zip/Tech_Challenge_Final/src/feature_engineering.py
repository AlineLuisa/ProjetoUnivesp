"""
=============================================================================
FEATURE ENGINEERING - Criação de Features Técnicas
=============================================================================
Módulo responsável por criar features avançadas para o modelo de previsão.

Total de features criadas: 294

Categorias:
- Retornos e variações
- Médias móveis (SMA e EMA)
- Indicadores técnicos (RSI, MACD, Bollinger, Stochastic, ATR)
- Volatilidade
- Momentum e ROC
- Correlações entre ativos
- Regime de mercado
- Features de calendário

Autor: Gustavo
Data: 11 de Janeiro de 2026
=============================================================================
"""

import pandas as pd
import numpy as np
from typing import List


class FeatureEngineer:
    """
    Classe para criação de features técnicas avançadas.
    
    Exemplo de uso:
        engineer = FeatureEngineer()
        df = engineer.create_all_features(df)
    """
    
    def __init__(self):
        self.feature_names = []
    
    def create_all_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Cria todas as features avançadas.
        
        Args:
            df: DataFrame com dados dos ativos
        
        Returns:
            DataFrame com features adicionadas
        """
        print("\n" + "="*60)
        print("[CONFIG] CRIANDO FEATURES AVANÇADAS")
        print("="*60)
        
        df = df.copy()
        
        # Features para cada ativo
        assets = ['IBOV', 'DOLAR', 'PETROLEO', 'SELIC', 'PETR3', 'VALE3']
        
        for asset in assets:
            price_col = f'{asset}_Ultimo'
            if price_col not in df.columns:
                continue
            
            print(f"  -> Criando features para {asset}...")
            
            # Retornos
            df[f'{asset}_Return'] = df[price_col].pct_change()
            df[f'{asset}_Return_2d'] = df[price_col].pct_change(2)
            df[f'{asset}_Return_5d'] = df[price_col].pct_change(5)
            
            # Médias móveis
            for window in [5, 10, 20, 50, 100, 200]:
                df[f'{asset}_SMA_{window}'] = df[price_col].rolling(window).mean()
                df[f'{asset}_EMA_{window}'] = df[price_col].ewm(span=window).mean()
            
            # Posição relativa às médias
            df[f'{asset}_Above_SMA20'] = (df[price_col] > df[f'{asset}_SMA_20']).astype(int)
            df[f'{asset}_Above_SMA50'] = (df[price_col] > df[f'{asset}_SMA_50']).astype(int)
            df[f'{asset}_Above_SMA200'] = (df[price_col] > df[f'{asset}_SMA_200']).astype(int)
            
            # RSI
            df = self._calculate_rsi(df, price_col, asset)
            
            # MACD
            df = self._calculate_macd(df, price_col, asset)
            
            # Bollinger Bands
            df = self._calculate_bollinger(df, price_col, asset)
            
            # Stochastic Oscillator
            if f'{asset}_Maxima' in df.columns and f'{asset}_Minima' in df.columns:
                df = self._calculate_stochastic(df, asset)
            
            # ATR
            if f'{asset}_Maxima' in df.columns and f'{asset}_Minima' in df.columns:
                df = self._calculate_atr(df, asset)
            
            # Volatilidade
            for window in [5, 10, 20]:
                df[f'{asset}_Volatility_{window}'] = df[f'{asset}_Return'].rolling(window).std()
            
            # Momentum
            for period in [5, 10, 20]:
                df[f'{asset}_Momentum_{period}'] = df[price_col] - df[price_col].shift(period)
            
            # Rate of Change (ROC)
            for period in [5, 10, 20]:
                df[f'{asset}_ROC_{period}'] = (df[price_col] / df[price_col].shift(period) - 1) * 100
        
        # Features de correlação entre ativos
        df = self._create_correlation_features(df)
        
        # Features de regime de mercado
        df = self._create_regime_features(df)
        
        # Lag features do IBOV
        df = self._create_lag_features(df)
        
        # Features de calendário
        df = self._create_calendar_features(df)
        
        # Remover NaN
        df = df.dropna()
        
        self.feature_names = [c for c in df.columns if c not in ['Data', 'Target']]
        
        print(f"\n[OK] Total de features criadas: {len(self.feature_names)}")
        
        return df
    
    def _calculate_rsi(self, df: pd.DataFrame, price_col: str, asset: str, 
                       periods: List[int] = [7, 14, 21]) -> pd.DataFrame:
        """Calcula RSI para múltiplos períodos."""
        for period in periods:
            delta = df[price_col].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            
            avg_gain = gain.rolling(window=period).mean()
            avg_loss = loss.rolling(window=period).mean()
            
            rs = avg_gain / (avg_loss + 1e-10)
            df[f'{asset}_RSI_{period}'] = 100 - (100 / (1 + rs))
        
        return df
    
    def _calculate_macd(self, df: pd.DataFrame, price_col: str, asset: str) -> pd.DataFrame:
        """Calcula MACD e histograma."""
        ema_12 = df[price_col].ewm(span=12).mean()
        ema_26 = df[price_col].ewm(span=26).mean()
        
        df[f'{asset}_MACD'] = ema_12 - ema_26
        df[f'{asset}_MACD_Signal'] = df[f'{asset}_MACD'].ewm(span=9).mean()
        df[f'{asset}_MACD_Hist'] = df[f'{asset}_MACD'] - df[f'{asset}_MACD_Signal']
        
        return df
    
    def _calculate_bollinger(self, df: pd.DataFrame, price_col: str, asset: str,
                            period: int = 20, num_std: float = 2.0) -> pd.DataFrame:
        """Calcula Bollinger Bands."""
        sma = df[price_col].rolling(period).mean()
        std = df[price_col].rolling(period).std()
        
        df[f'{asset}_BB_Upper'] = sma + (std * num_std)
        df[f'{asset}_BB_Lower'] = sma - (std * num_std)
        df[f'{asset}_BB_Width'] = (df[f'{asset}_BB_Upper'] - df[f'{asset}_BB_Lower']) / sma
        df[f'{asset}_BB_Position'] = (df[price_col] - df[f'{asset}_BB_Lower']) / \
                                     (df[f'{asset}_BB_Upper'] - df[f'{asset}_BB_Lower'] + 1e-10)
        
        return df
    
    def _calculate_stochastic(self, df: pd.DataFrame, asset: str, 
                              k_period: int = 14, d_period: int = 3) -> pd.DataFrame:
        """Calcula Stochastic Oscillator."""
        high_col = f'{asset}_Maxima'
        low_col = f'{asset}_Minima'
        close_col = f'{asset}_Ultimo'
        
        lowest_low = df[low_col].rolling(k_period).min()
        highest_high = df[high_col].rolling(k_period).max()
        
        df[f'{asset}_Stoch_K'] = 100 * (df[close_col] - lowest_low) / (highest_high - lowest_low + 1e-10)
        df[f'{asset}_Stoch_D'] = df[f'{asset}_Stoch_K'].rolling(d_period).mean()
        
        return df
    
    def _calculate_atr(self, df: pd.DataFrame, asset: str, period: int = 14) -> pd.DataFrame:
        """Calcula Average True Range."""
        high_col = f'{asset}_Maxima'
        low_col = f'{asset}_Minima'
        close_col = f'{asset}_Ultimo'
        
        tr1 = df[high_col] - df[low_col]
        tr2 = abs(df[high_col] - df[close_col].shift())
        tr3 = abs(df[low_col] - df[close_col].shift())
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        df[f'{asset}_ATR'] = tr.rolling(period).mean()
        
        return df
    
    def _create_correlation_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Cria features de correlação entre ativos."""
        assets = ['DOLAR', 'PETROLEO', 'PETR3', 'VALE3']
        
        for asset in assets:
            ret_col = f'{asset}_Return'
            if ret_col in df.columns:
                df[f'Corr_IBOV_{asset}_20'] = df['IBOV_Return'].rolling(20).corr(df[ret_col])
        
        return df
    
    def _create_regime_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Cria features de regime de mercado."""
        # Regime de volatilidade
        vol_20 = df['IBOV_Return'].rolling(20).std()
        vol_60 = df['IBOV_Return'].rolling(60).std()
        df['Volatility_Regime'] = (vol_20 > vol_60).astype(int)
        
        # Regime de tendência
        df['Trend_Regime'] = (df['IBOV_SMA_20'] > df['IBOV_SMA_50']).astype(int)
        
        # Dias consecutivos de alta/baixa
        df['IBOV_Direction'] = (df['IBOV_Return'] > 0).astype(int)
        df['Consecutive_Up'] = df['IBOV_Direction'].groupby(
            (df['IBOV_Direction'] != df['IBOV_Direction'].shift()).cumsum()
        ).cumsum() * df['IBOV_Direction']
        df['Consecutive_Down'] = (1 - df['IBOV_Direction']).groupby(
            (df['IBOV_Direction'] != df['IBOV_Direction'].shift()).cumsum()
        ).cumsum() * (1 - df['IBOV_Direction'])
        
        return df
    
    def _create_lag_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Cria lag features do IBOV."""
        for lag in [1, 2, 3, 5, 7, 10]:
            df[f'IBOV_Return_Lag_{lag}'] = df['IBOV_Return'].shift(lag)
            df[f'IBOV_RSI_14_Lag_{lag}'] = df['IBOV_RSI_14'].shift(lag)
        
        return df
    
    def _create_calendar_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Cria features de calendário."""
        df['DayOfWeek'] = df['Data'].dt.dayofweek
        df['Month'] = df['Data'].dt.month
        df['Quarter'] = df['Data'].dt.quarter
        df['IsMonthStart'] = df['Data'].dt.is_month_start.astype(int)
        df['IsMonthEnd'] = df['Data'].dt.is_month_end.astype(int)
        
        return df


def create_target(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cria a variável target: 1 se IBOV fecha em alta no dia seguinte, 0 caso contrário.
    
    Args:
        df: DataFrame com features
    
    Returns:
        DataFrame com coluna Target adicionada
    """
    df = df.copy()
    df['Target'] = (df['IBOV_Return'].shift(-1) > 0).astype(int)
    df = df.iloc[:-1]  # Remover última linha (sem target)
    return df
