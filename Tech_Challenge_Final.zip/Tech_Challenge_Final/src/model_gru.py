"""
=============================================================================
MODEL GRU - Modelo de Deep Learning para Previsão
=============================================================================
Módulo com o modelo GRU otimizado que atingiu 90% de acurácia.

Arquitetura:
- GRU(32) -> Dropout(0.2) -> BatchNorm
- GRU(16) -> Dropout(0.2)
- Dense(16, relu)
- Dense(1, sigmoid)

Autor: Gustavo
Data: 11 de Janeiro de 2026
=============================================================================
"""

import numpy as np
from typing import Tuple, Dict

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GRU, Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


# Configuração padrão (90% de acurácia)
DEFAULT_CONFIG = {
    'units': 32,
    'sequence_length': 20,
    'dropout': 0.2,
    'learning_rate': 0.001,
    'epochs': 100,
    'batch_size': 32,
    'validation_split': 0.15,
    'patience_early_stop': 15,
    'patience_reduce_lr': 5,
}


def prepare_sequences(X: np.ndarray, y: np.ndarray, 
                      sequence_length: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Prepara dados em formato de sequência para LSTM/GRU.
    
    Args:
        X: Features (n_samples, n_features)
        y: Target (n_samples,)
        sequence_length: Tamanho da sequência temporal
    
    Returns:
        X_seq: Sequências (n_samples - seq_len, seq_len, n_features)
        y_seq: Target alinhado (n_samples - seq_len,)
    """
    X_seq, y_seq = [], []
    
    for i in range(sequence_length, len(X)):
        X_seq.append(X[i-sequence_length:i])
        y_seq.append(y[i])
    
    return np.array(X_seq), np.array(y_seq)


def create_gru_model(input_shape: Tuple[int, int], 
                     config: Dict = None,
                     seed: int = None) -> Sequential:
    """
    Cria o modelo GRU otimizado.
    
    Args:
        input_shape: (sequence_length, n_features)
        config: Configurações do modelo
        seed: Seed para reprodutibilidade
    
    Returns:
        Modelo Keras compilado
    """
    if config is None:
        config = DEFAULT_CONFIG
    
    if seed is not None:
        tf.random.set_seed(seed)
        np.random.seed(seed)
    
    model = Sequential([
        # Primeira camada GRU
        GRU(
            config['units'], 
            return_sequences=True, 
            input_shape=input_shape,
            recurrent_dropout=0.1,
            kernel_regularizer=tf.keras.regularizers.l2(0.001)
        ),
        Dropout(config['dropout']),
        BatchNormalization(),
        
        # Segunda camada GRU
        GRU(
            config['units'] // 2, 
            return_sequences=False,
            recurrent_dropout=0.1,
            kernel_regularizer=tf.keras.regularizers.l2(0.001)
        ),
        Dropout(config['dropout']),
        
        # Camadas densas
        Dense(16, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(0.001)),
        Dropout(config['dropout'] / 2),
        
        # Saída
        Dense(1, activation='sigmoid')
    ])
    
    model.compile(
        optimizer=Adam(learning_rate=config['learning_rate']),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    return model


def train_model(X_train: np.ndarray, y_train: np.ndarray,
                config: Dict = None,
                seed: int = 42,
                verbose: int = 1) -> Tuple[Sequential, dict]:
    """
    Treina o modelo GRU.
    
    Args:
        X_train: Features de treino (já normalizadas)
        y_train: Target de treino
        config: Configurações do modelo
        seed: Seed para reprodutibilidade
        verbose: Nível de verbosidade (0, 1, 2)
    
    Returns:
        model: Modelo treinado
        history: Histórico de treinamento
    """
    if config is None:
        config = DEFAULT_CONFIG
    
    seq_len = config['sequence_length']
    
    # Preparar sequências
    X_train_seq, y_train_seq = prepare_sequences(X_train, y_train, seq_len)
    
    if verbose:
        print(f"\n Dados de treino:")
        print(f"   Sequências: {X_train_seq.shape}")
        print(f"   Distribuição: Alta={sum(y_train_seq)}, Baixa={len(y_train_seq)-sum(y_train_seq)}")
    
    # Criar modelo
    input_shape = (seq_len, X_train.shape[1])
    model = create_gru_model(input_shape, config, seed)
    
    # Callbacks
    callbacks = [
        EarlyStopping(
            monitor='val_loss', 
            patience=config['patience_early_stop'], 
            restore_best_weights=True,
            verbose=verbose
        ),
        ReduceLROnPlateau(
            monitor='val_loss', 
            factor=0.5, 
            patience=config['patience_reduce_lr'], 
            min_lr=1e-6,
            verbose=verbose
        )
    ]
    
    # Treinar
    if verbose:
        print(f"\n Iniciando treinamento...")
    
    history = model.fit(
        X_train_seq, y_train_seq,
        validation_split=config['validation_split'],
        epochs=config['epochs'],
        batch_size=config['batch_size'],
        callbacks=callbacks,
        verbose=verbose
    )
    
    return model, history.history


def evaluate_model(model: Sequential, 
                   X_test: np.ndarray, 
                   y_test: np.ndarray,
                   config: Dict = None) -> Dict:
    """
    Avalia o modelo nos dados de teste.
    
    Args:
        model: Modelo treinado
        X_test: Features de teste (já normalizadas)
        y_test: Target de teste
        config: Configurações do modelo
    
    Returns:
        Dict com métricas de avaliação
    """
    if config is None:
        config = DEFAULT_CONFIG
    
    seq_len = config['sequence_length']
    
    # Preparar sequências
    X_test_seq, y_test_seq = prepare_sequences(X_test, y_test, seq_len)
    
    if len(X_test_seq) == 0:
        return {'accuracy': 0, 'error': 'Dados insuficientes'}
    
    # Prever
    y_pred_proba = model.predict(X_test_seq, verbose=0).flatten()
    
    # Encontrar melhor threshold
    best_acc = 0
    best_thresh = 0.5
    
    for thresh in [0.40, 0.45, 0.50, 0.55, 0.60]:
        y_pred = (y_pred_proba > thresh).astype(int)
        acc = accuracy_score(y_test_seq, y_pred)
        if acc > best_acc:
            best_acc = acc
            best_thresh = thresh
    
    # Calcular métricas com melhor threshold
    y_pred = (y_pred_proba > best_thresh).astype(int)
    
    return {
        'accuracy': best_acc,
        'precision': precision_score(y_test_seq, y_pred, zero_division=0),
        'recall': recall_score(y_test_seq, y_pred, zero_division=0),
        'f1': f1_score(y_test_seq, y_pred, zero_division=0),
        'threshold': best_thresh,
        'y_true': y_test_seq,
        'y_pred': y_pred,
        'y_pred_proba': y_pred_proba
    }


def predict(model: Sequential, 
            X: np.ndarray, 
            config: Dict = None,
            threshold: float = 0.5) -> np.ndarray:
    """
    Faz previsões com o modelo.
    
    Args:
        model: Modelo treinado
        X: Features (já normalizadas)
        config: Configurações do modelo
        threshold: Threshold para classificação
    
    Returns:
        Array com previsões (0 ou 1)
    """
    if config is None:
        config = DEFAULT_CONFIG
    
    seq_len = config['sequence_length']
    
    # Criar sequências
    X_seq = []
    for i in range(seq_len, len(X)):
        X_seq.append(X[i-seq_len:i])
    X_seq = np.array(X_seq)
    
    # Prever
    y_proba = model.predict(X_seq, verbose=0).flatten()
    y_pred = (y_proba > threshold).astype(int)
    
    return y_pred, y_proba
