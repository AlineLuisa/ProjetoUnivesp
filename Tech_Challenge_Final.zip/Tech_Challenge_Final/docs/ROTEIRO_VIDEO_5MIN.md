#  ROTEIRO DO VÍDEO (5 MINUTOS)

## Visão Gerencial - Como Interpretar os Resultados

---

## INFORMAÇÕES TÉCNICAS

- **Duração:** Máximo 5 minutos
- **Requisito:** Todos os membros do grupo devem aparecer
- **Foco:** Visão GERENCIAL (não técnica)
- **Objetivo:** Explicar como interpretar os resultados

---

## ESTRUTURA DO VÍDEO

###  ABERTURA (0:00 - 0:30) - 30 segundos

**[Todos os membros aparecem na tela]**

**APRESENTADOR 1:**
> "Olá! Somos a equipe [NOME DO GRUPO] e vamos apresentar nosso modelo de previsão do IBOVESPA."

**[Cada membro se apresenta brevemente]**
> "Eu sou [Nome], [Nome], [Nome]..."

**APRESENTADOR 1:**
> "Nosso desafio foi criar um modelo que prevê se o IBOVESPA vai subir ou cair no dia seguinte, com pelo menos 75% de acerto. E conseguimos!"

---

###  O PROBLEMA (0:30 - 1:00) - 30 segundos

**APRESENTADOR 2:**

> "Imaginem que vocês são gestores de um fundo de investimentos. Todo dia precisam decidir: comprar ou vender?"

> "Se soubessem com 80% de certeza que amanhã o mercado vai subir, a decisão fica muito mais fácil, certo?"

> "É exatamente isso que nosso modelo faz: ele analisa os últimos 20 dias do mercado e diz se amanhã provavelmente será um dia de ALTA ou de BAIXA."

---

###  COMO FUNCIONA (1:00 - 2:00) - 1 minuto

**APRESENTADOR 3:**

> "De forma simples: nosso modelo é como um analista que olha para vários indicadores ao mesmo tempo."

**[Mostrar slide/imagem com os indicadores]**

> "Ele analisa:"
> - "O próprio IBOVESPA - como se comportou nos últimos dias"
> - "O Dólar - que afeta empresas exportadoras"
> - "O Petróleo - que impacta a Petrobras"
> - "A Taxa Selic - que influencia todo o mercado"
> - "E as ações da Vale e Petrobras - que representam 25% do índice"

> "São 294 indicadores diferentes sendo analisados simultaneamente. Nenhum humano conseguiria processar tudo isso em tempo real."

---

###  OS RESULTADOS (2:00 - 3:30) - 1 minuto e 30 segundos

**APRESENTADOR 1:**

> "Agora, o mais importante: os resultados."

**[Mostrar tela com métricas]**

> "Nosso modelo atingiu 80% de acurácia nos últimos 30 dias de teste. A meta era 75%, então superamos!"

> "O que isso significa na prática?"

**[Mostrar exemplo visual]**

> "Em 30 dias de pregão:"
> - "Acertamos 24 previsões"
> - "Erramos apenas 6"

> "Se um gestor seguisse nosso modelo, teria tomado a decisão correta em 8 de cada 10 dias."

**APRESENTADOR 2:**

> "Importante destacar: testamos o modelo em diferentes períodos do mercado - em momentos de alta, de baixa, de crise. E ele manteve consistência."

> "Isso mostra que não é um modelo que só funciona em condições específicas."

---

###  LIMITAÇÕES E CUIDADOS (3:30 - 4:15) - 45 segundos

**APRESENTADOR 3:**

> "Mas precisamos ser honestos sobre as limitações."

> "Primeiro: 80% não é 100%. Em 2 de cada 10 dias, o modelo erra. Então não deve ser a única fonte de decisão."

> "Segundo: o mercado muda. Eventos inesperados como crises políticas ou pandemias podem afetar a precisão. Por isso recomendamos retreinar o modelo mensalmente."

> "Terceiro: o modelo prevê DIREÇÃO, não MAGNITUDE. Ele diz se vai subir, mas não quanto."

> "Use como uma ferramenta de apoio, não como verdade absoluta."

---

###  RECOMENDAÇÕES DE USO (4:15 - 4:45) - 30 segundos

**APRESENTADOR 1:**

> "Como recomendamos usar este modelo?"

> "1. Como filtro inicial: se o modelo diz BAIXA, talvez seja hora de ser mais conservador"

> "2. Combinado com análise humana: o modelo é um input, não a decisão final"

> "3. Com monitoramento: acompanhem a acurácia semana a semana"

> "4. Com retreinamento: atualizem com dados novos todo mês"

---

###  ENCERRAMENTO (4:45 - 5:00) - 15 segundos

**[Todos os membros na tela]**

**APRESENTADOR 2:**
> "Resumindo: criamos um modelo que acerta 80% das vezes se o IBOVESPA vai subir ou cair. Superamos a meta de 75% e entregamos uma ferramenta prática para apoiar decisões de investimento."

**TODOS:**
> "Obrigado!"

---

## DICAS DE GRAVAÇÃO

### Preparação:
- [ ] Testar áudio e vídeo antes
- [ ] Iluminação adequada (luz na frente, não atrás)
- [ ] Ambiente silencioso
- [ ] Roupa adequada (evitar listras finas)

### Durante a gravação:
- [ ] Falar pausadamente e com clareza
- [ ] Olhar para a câmera
- [ ] Usar gestos naturais
- [ ] Mostrar slides/telas quando mencionado

### Edição:
- [ ] Cortar pausas longas
- [ ] Adicionar slides nos momentos certos
- [ ] Verificar se áudio está audível
- [ ] Confirmar que todos aparecem

### Checklist final:
- [ ] Vídeo tem no máximo 5 minutos?
- [ ] Todos os membros aparecem?
- [ ] Foco é gerencial (não muito técnico)?
- [ ] Explica como interpretar os resultados?

---

## SLIDES SUGERIDOS PARA O VÍDEO

### Slide 1: Título
```
MODELO DE PREVISÃO IBOVESPA
Acurácia: 80% 
[Nomes do grupo]
```

### Slide 2: O Problema
```
DESAFIO:
Prever se IBOVESPA sobe ALTA ou desce BAIXA
Meta: 75% de acerto
```

### Slide 3: Indicadores
```
O QUE O MODELO ANALISA:
• IBOVESPA (histórico)
• Dólar
• Petróleo
• Selic
• PETR3 e VALE3
= 294 indicadores
```

### Slide 4: Resultados
```
RESULTADOS:
 Acurácia: 80%
 Meta superada!

Em 30 dias:
• 24 acertos
• 6 erros
```

### Slide 5: Uso Recomendado
```
COMO USAR:
1. Filtro inicial de decisões
2. Combinado com análise humana
3. Com monitoramento contínuo
4. Retreinamento mensal
```

---

## FALAS ALTERNATIVAS (se precisar ajustar tempo)

### Se estiver LONGO (cortar):
- Reduzir exemplos
- Simplificar explicação técnica
- Encurtar apresentação individual

### Se estiver CURTO (adicionar):
- Mostrar o modelo rodando ao vivo
- Dar mais exemplos práticos
- Explicar um indicador específico (ex: RSI)

---

## EXEMPLO DE DIVISÃO POR MEMBRO (3 pessoas)

| Membro | Seção | Tempo |
|--------|-------|-------|
| Membro 1 | Abertura + Resultados + Encerramento | ~2 min |
| Membro 2 | O Problema + Limitações | ~1.5 min |
| Membro 3 | Como Funciona + Recomendações | ~1.5 min |

---

## EXEMPLO DE DIVISÃO POR MEMBRO (4 pessoas)

| Membro | Seção | Tempo |
|--------|-------|-------|
| Membro 1 | Abertura | 30 seg |
| Membro 2 | O Problema + Como Funciona | 1.5 min |
| Membro 3 | Resultados | 1.5 min |
| Membro 4 | Limitações + Recomendações + Encerramento | 1.5 min |

---

**Boa gravação! **
