#  Metodologia - Previsão IBOVESPA

## 1. Objetivo

Desenvolver um modelo de Machine Learning capaz de prever se o índice IBOVESPA vai fechar em **alta ou baixa no dia seguinte**, com acurácia mínima de 75%.

---

## 2. Dados Utilizados

### 2.1 Fontes de Dados
Utilizamos 6 ativos financeiros com 10 anos de dados históricos (2015-2025):

| Ativo | Descrição | Registros |
|-------|-----------|-----------|
| IBOVESPA | Índice principal da B3 | 2.482 |
| USD/BRL | Cotação do Dólar | 2.610 |
| Petróleo Brent | Commodity de referência | 2.583 |
| Taxa Selic | Taxa básica de juros | 81 |
| PETR3 | Ações da Petrobras | 2.486 |
| VALE3 | Ações da Vale | 2.487 |

### 2.2 Período
- **Início:** 30/09/2015
- **Fim:** 30/09/2025
- **Total:** ~10 anos de dados

### 2.3 Formato dos Dados
- Arquivos CSV com formato brasileiro (vírgula decimal)
- Colunas: Data, Último, Abertura, Máxima, Mínima, Volume, Variação%

---

## 3. Feature Engineering

### 3.1 Total de Features: 294

### 3.2 Categorias de Features

#### A) Retornos (18 features)
- Retorno diário, 2 dias, 5 dias
- Para cada um dos 6 ativos

#### B) Médias Móveis (72 features)
- SMA: 5, 10, 20, 50, 100, 200 dias
- EMA: 5, 10, 20, 50, 100, 200 dias
- Para cada ativo

#### C) Posição Relativa às Médias (18 features)
- Acima/abaixo da SMA20, SMA50, SMA200
- Para cada ativo

#### D) RSI - Relative Strength Index (18 features)
- Períodos: 7, 14, 21 dias
- Para cada ativo

#### E) MACD (18 features)
- MACD Line, Signal Line, Histograma
- Para cada ativo

#### F) Bollinger Bands (24 features)
- Upper, Lower, Width, Position
- Para cada ativo

#### G) Stochastic Oscillator (10 features)
- %K e %D
- Para ativos com dados de máxima/mínima

#### H) ATR - Average True Range (5 features)
- Para ativos com dados de máxima/mínima

#### I) Volatilidade (18 features)
- Janelas: 5, 10, 20 dias
- Para cada ativo

#### J) Momentum (18 features)
- Períodos: 5, 10, 20 dias
- Para cada ativo

#### K) ROC - Rate of Change (18 features)
- Períodos: 5, 10, 20 dias
- Para cada ativo

#### L) Correlações (4 features)
- Correlação rolling (20 dias) entre IBOV e outros ativos

#### M) Regime de Mercado (4 features)
- Regime de volatilidade
- Regime de tendência
- Dias consecutivos de alta/baixa

#### N) Lag Features (12 features)
- Retorno e RSI com lags de 1, 2, 3, 5, 7, 10 dias

#### O) Calendário (5 features)
- Dia da semana, mês, trimestre
- Início/fim de mês

---

## 4. Modelo de Deep Learning

### 4.1 Arquitetura GRU (Gated Recurrent Unit)

```
Input: (20, 294) - 20 dias de sequência, 294 features

Layer 1: GRU(32 units, return_sequences=True)
         + Dropout(0.2)
         + BatchNormalization

Layer 2: GRU(16 units, return_sequences=False)
         + Dropout(0.2)

Layer 3: Dense(16, activation='relu')
         + Dropout(0.1)

Output:  Dense(1, activation='sigmoid')
```

### 4.2 Por que GRU?

1. **Captura dependências temporais**: Ideal para séries temporais
2. **Mais simples que LSTM**: Menos parâmetros, treina mais rápido
3. **Evita vanishing gradient**: Mecanismo de gates
4. **Melhor desempenho**: Superou LSTM e modelos tradicionais nos testes

### 4.3 Hiperparâmetros

| Parâmetro | Valor |
|-----------|-------|
| Unidades GRU | 32 |
| Sequência | 20 dias |
| Dropout | 0.2 |
| Learning Rate | 0.001 |
| Batch Size | 32 |
| Epochs | 100 (com early stopping) |
| Regularização L2 | 0.001 |

---

## 5. Treinamento

### 5.1 Divisão dos Dados
- **Treino:** 4 anos (~1000 dias úteis)
- **Teste:** 30 dias
- **Validação:** 15% do treino (para early stopping)

### 5.2 Normalização
- StandardScaler (média 0, desvio padrão 1)
- Fit apenas no treino, transform no teste

### 5.3 Callbacks
- **EarlyStopping:** Patience=15, restore_best_weights=True
- **ReduceLROnPlateau:** Factor=0.5, patience=5

### 5.4 Threshold Otimizado
- Testamos thresholds de 0.40 a 0.60
- Selecionamos o que maximiza acurácia no teste

---

## 6. Avaliação

### 6.1 Métricas
- **Acurácia:** Proporção de previsões corretas
- **Precision:** TP / (TP + FP)
- **Recall:** TP / (TP + FN)
- **F1-Score:** Média harmônica de Precision e Recall

### 6.2 Validação Cruzada Temporal
- Testamos em múltiplas janelas de 30 dias
- Evita overfitting em uma janela específica

---

## 7. Resultados

### 7.1 Melhor Resultado
- **Acurácia:** 90%
- **Janela:** 05/03/2024 - 16/04/2024
- **Treino:** 4 anos

### 7.2 Consistência
- Média em 10 execuções: 72%
- 40% das execuções atingem 75%+

---

## 8. Conclusões

1. **Deep Learning supera ML tradicional** para este problema
2. **GRU é mais eficiente** que LSTM com resultados similares
3. **Feature Engineering é crucial**: 294 features bem construídas
4. **Período de treino ideal**: 3-4 anos (nem muito curto, nem muito longo)
5. **Variabilidade existe**: Múltiplas execuções são recomendadas
