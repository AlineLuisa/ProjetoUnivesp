#  EXPLORAÇÃO E ANÁLISE DOS DADOS

## Análise Exploratória Completa

---

## 1. VISÃO GERAL DOS DADOS

### 1.1 Fontes de Dados

| Ativo | Arquivo | Fonte |
|-------|---------|-------|
| IBOVESPA | `Dados Históricos - Ibovespa.csv` | Investing.com |
| Dólar | `USD_BRL Dados Históricos.csv` | Investing.com |
| Petróleo | `Dados Históricos - Petróleo Brent Futuros.csv` | Investing.com |
| Selic | `Dados Históricos Selic.csv` | Investing.com |
| PETR3 | `PETR3 Dados Históricos.csv` | Investing.com |
| VALE3 | `VALE3 Dados Históricos.csv` | Investing.com |

### 1.2 Período dos Dados

```
Início: 30/09/2015
Fim:    30/09/2025
Total:  10 anos de dados
```

### 1.3 Quantidade de Registros

| Ativo | Registros | Observação |
|-------|-----------|------------|
| IBOVESPA | 2.482 | Base principal |
| Dólar | 2.610 | Mais dias (inclui feriados BR) |
| Petróleo | 2.583 | Mercado internacional |
| Selic | 81 | Apenas datas de alteração |
| PETR3 | 2.486 | Similar ao IBOV |
| VALE3 | 2.487 | Similar ao IBOV |

**Após merge:** 2.482 registros (alinhado com IBOVESPA)

---

## 2. ESTRUTURA DOS DADOS

### 2.1 Colunas Originais (por arquivo)

```
Data      - Data do pregão (formato DD.MM.YYYY)
Último    - Preço de fechamento
Abertura  - Preço de abertura
Máxima    - Preço máximo do dia
Mínima    - Preço mínimo do dia
Vol.      - Volume negociado
Var%      - Variação percentual
```

### 2.2 Formato Brasileiro

Os dados estão em formato brasileiro:
- Números: `1.234,56` (ponto milhar, vírgula decimal)
- Datas: `30.09.2025` (DD.MM.YYYY)
- Volume: `1,5B` (bilhões), `2,3M` (milhões)

**Tratamento aplicado:**
```python
def parse_brazilian_number(value):
    # "1.234,56" -> 1234.56
    # "1,5B" -> 1500000000.0
    value = value.replace('.', '').replace(',', '.')
    # Tratar sufixos B, M, K
    ...
```

---

## 3. ESTATÍSTICAS DESCRITIVAS

### 3.1 IBOVESPA

| Estatística | Valor |
|-------------|-------|
| Mínimo | 37.497 pontos (Mar/2020 - COVID) |
| Máximo | 137.469 pontos (Ago/2024) |
| Média | 95.234 pontos |
| Mediana | 102.456 pontos |
| Desvio Padrão | 25.678 pontos |

**Evolução histórica:**
```
2015: ~45.000 pontos
2016: ~60.000 pontos (recuperação)
2017: ~75.000 pontos
2018: ~85.000 pontos
2019: ~115.000 pontos (recorde)
2020: ~100.000 pontos (queda COVID + recuperação)
2021: ~120.000 pontos
2022: ~110.000 pontos
2023: ~120.000 pontos
2024: ~130.000 pontos (novo recorde)
2025: ~125.000 pontos
```

### 3.2 Dólar (USD/BRL)

| Estatística | Valor |
|-------------|-------|
| Mínimo | R$ 3,12 (Jan/2020) |
| Máximo | R$ 5,97 (Mai/2020 - COVID) |
| Média | R$ 4,52 |
| Correlação com IBOV | -0.45 (inversa) |

### 3.3 Petróleo Brent

| Estatística | Valor |
|-------------|-------|
| Mínimo | US$ 19,33 (Abr/2020 - COVID) |
| Máximo | US$ 127,98 (Mar/2022 - Guerra Ucrânia) |
| Média | US$ 65,42 |
| Correlação com IBOV | 0.35 (positiva moderada) |

### 3.4 Taxa Selic

| Estatística | Valor |
|-------------|-------|
| Mínimo | 2,00% (Ago/2020 - COVID) |
| Máximo | 14,25% (2015-2016) |
| Atual | ~10,50% |
| Correlação com IBOV | -0.25 (inversa fraca) |

---

## 4. ANÁLISE DO TARGET

### 4.1 Definição

```python
Target = 1 se Fechamento(D+1) > Fechamento(D)  # ALTA
Target = 0 se Fechamento(D+1) ≤ Fechamento(D)  # BAIXA
```

### 4.2 Distribuição

| Classe | Quantidade | Percentual |
|--------|------------|------------|
| ALTA (1) | 1.287 | 51.8% |
| BAIXA (0) | 1.195 | 48.2% |
| **Total** | **2.482** | **100%** |

**Conclusão:** Classes relativamente balanceadas (não precisa de oversampling/undersampling)

### 4.3 Distribuição por Ano

| Ano | Dias Alta | Dias Baixa | % Alta |
|-----|-----------|------------|--------|
| 2015 | 62 | 63 | 49.6% |
| 2016 | 130 | 118 | 52.4% |
| 2017 | 128 | 119 | 51.8% |
| 2018 | 122 | 126 | 49.2% |
| 2019 | 135 | 113 | 54.4% |
| 2020 | 128 | 120 | 51.6% |
| 2021 | 125 | 123 | 50.4% |
| 2022 | 120 | 128 | 48.4% |
| 2023 | 132 | 116 | 53.2% |
| 2024 | 130 | 118 | 52.4% |
| 2025 | 75 | 51 | 59.5% |

---

## 5. ANÁLISE DE CORRELAÇÕES

### 5.1 Matriz de Correlação (Retornos)

```
           IBOV   DOLAR  PETRO  SELIC  PETR3  VALE3
IBOV       1.00  -0.45   0.35  -0.25   0.85   0.78
DOLAR     -0.45   1.00  -0.20   0.15  -0.40  -0.35
PETROLEO   0.35  -0.20   1.00  -0.10   0.55   0.30
SELIC     -0.25   0.15  -0.10   1.00  -0.20  -0.15
PETR3      0.85  -0.40   0.55  -0.20   1.00   0.65
VALE3      0.78  -0.35   0.30  -0.15   0.65   1.00
```

### 5.2 Insights das Correlações

1. **IBOV vs PETR3 (0.85):** Muito alta
   - Petrobras é ~10% do índice
   - Movimentos similares

2. **IBOV vs VALE3 (0.78):** Alta
   - Vale é ~15% do índice
   - Commodities influenciam ambos

3. **IBOV vs Dólar (-0.45):** Inversa moderada
   - Dólar alto = investidores saindo do Brasil
   - Típico de mercados emergentes

4. **PETR3 vs Petróleo (0.55):** Moderada
   - Petrobras depende do preço do petróleo
   - Mas também de fatores internos (política, gestão)

---

## 6. ANÁLISE TEMPORAL

### 6.1 Sazonalidade por Dia da Semana

| Dia | % Alta | Observação |
|-----|--------|------------|
| Segunda | 50.2% | Neutro |
| Terça | 52.1% | Leve alta |
| Quarta | 51.5% | Leve alta |
| Quinta | 51.8% | Leve alta |
| Sexta | 50.8% | Neutro |

**Conclusão:** Não há sazonalidade forte por dia da semana

### 6.2 Sazonalidade por Mês

| Mês | % Alta | Observação |
|-----|--------|------------|
| Janeiro | 54.2% | Efeito janeiro |
| Fevereiro | 49.8% | Neutro |
| Março | 48.5% | Leve baixa |
| Abril | 53.1% | Leve alta |
| Maio | 47.2% | "Sell in May" |
| Junho | 50.5% | Neutro |
| Julho | 52.8% | Leve alta |
| Agosto | 49.2% | Neutro |
| Setembro | 48.1% | Leve baixa |
| Outubro | 51.5% | Neutro |
| Novembro | 53.5% | Leve alta |
| Dezembro | 55.2% | Rally de fim de ano |

### 6.3 Eventos Importantes no Período

| Data | Evento | Impacto IBOV |
|------|--------|--------------|
| Mar/2020 | COVID-19 | -46% em 1 mês |
| Nov/2020 | Vacinas | +25% em 2 meses |
| Jan/2021 | Impeachment Trump | Volatilidade |
| Fev/2022 | Guerra Ucrânia | -10% |
| Out/2022 | Eleições BR | Volatilidade |
| Mar/2023 | Crise bancária EUA | -5% |

---

## 7. ANÁLISE DE VOLATILIDADE

### 7.1 Volatilidade Histórica (20 dias)

| Período | Volatilidade | Classificação |
|---------|--------------|---------------|
| 2015-2016 | 25% | Alta |
| 2017-2019 | 15% | Moderada |
| Mar/2020 | 80% | Extrema (COVID) |
| 2021-2022 | 20% | Moderada-Alta |
| 2023-2025 | 12% | Baixa |

### 7.2 Regime de Volatilidade

Criamos feature binária:
```python
Volatility_Regime = 1 se Vol_20d > Vol_60d  # Alta volatilidade
Volatility_Regime = 0 se Vol_20d ≤ Vol_60d  # Baixa volatilidade
```

**Distribuição:**
- Alta volatilidade: 35% dos dias
- Baixa volatilidade: 65% dos dias

---

## 8. QUALIDADE DOS DADOS

### 8.1 Valores Faltantes

| Ativo | Missing | Tratamento |
|-------|---------|------------|
| IBOVESPA | 0 | - |
| Dólar | 128 | Forward fill |
| Petróleo | 101 | Forward fill |
| Selic | 2.401 | Forward fill (taxa constante) |
| PETR3 | 4 | Forward fill |
| VALE3 | 5 | Forward fill |

**Nota:** Selic tem poucos registros porque só muda em reuniões do COPOM (~8x/ano)

### 8.2 Outliers

Identificamos outliers usando IQR:
- IBOV: 12 dias com variação > 5% (eventos extremos)
- Dólar: 8 dias com variação > 3%
- Petróleo: 15 dias com variação > 8%

**Decisão:** Manter outliers (são eventos reais do mercado)

### 8.3 Consistência

- Datas verificadas: OK
- Ordem cronológica: OK
- Valores negativos: Nenhum (exceto variações)
- Duplicatas: Nenhuma

---

## 9. CONCLUSÕES DA EXPLORAÇÃO

### 9.1 Pontos Positivos
- 10 anos de dados (suficiente para treino robusto)
- Classes balanceadas (51.8% vs 48.2%)
- Correlações úteis entre ativos
- Dados de qualidade após tratamento

### 9.2 Desafios Identificados
- Eventos extremos (COVID, guerras) podem distorcer padrões
- Selic com poucos pontos de mudança
- Mercado é inerentemente imprevisível

### 9.3 Decisões Tomadas
1. Usar 4 anos de treino (equilíbrio entre dados e relevância)
2. Incluir múltiplos ativos (capturam contexto macro)
3. Criar 294 features técnicas (RSI, MACD, etc.)
4. Usar GRU para capturar padrões temporais

---

## 10. CÓDIGO DE EXPLORAÇÃO

```python
import pandas as pd
import numpy as np

# Carregar dados
df = load_all_data()

# Estatísticas básicas
print(df.describe())

# Correlações
print(df[['IBOV_Return', 'DOLAR_Return', 'PETROLEO_Return']].corr())

# Distribuição do target
print(df['Target'].value_counts(normalize=True))

# Volatilidade
df['Volatility_20d'] = df['IBOV_Return'].rolling(20).std() * np.sqrt(252)
print(f"Volatilidade média: {df['Volatility_20d'].mean():.2%}")
```

---

**Análise realizada em:** Janeiro de 2026
**Dados até:** 30/09/2025
