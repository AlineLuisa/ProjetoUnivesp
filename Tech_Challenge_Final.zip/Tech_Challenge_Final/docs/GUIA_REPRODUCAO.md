#  Guia de Reprodução dos Resultados

Este guia explica como reproduzir os resultados do modelo de previsão do IBOVESPA.

---

## 1. Pré-requisitos

### 1.1 Python
- Python 3.10 ou superior
- pip (gerenciador de pacotes)

### 1.2 Hardware Recomendado
- RAM: 8GB mínimo
- CPU: Qualquer processador moderno
- GPU: Opcional (acelera treinamento)

---

## 2. Instalação

### 2.1 Clonar/Copiar o Projeto
```bash
# Copiar a pasta Tech_Challenge_Final para seu computador
```

### 2.2 Criar Ambiente Virtual (Recomendado)
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 2.3 Instalar Dependências
```bash
pip install -r requirements.txt
```

---

## 3. Estrutura de Arquivos Necessária

```
Tech_Challenge_Final/
├── dados/                       # OBRIGATÓRIO
│   ├── Dados Históricos - Ibovespa.csv
│   ├── USD_BRL Dados Históricos.csv
│   ├── Dados Históricos - Petróleo Brent Futuros.csv
│   ├── Dados Históricos Selic.csv
│   ├── PETR3 Dados Históricos.csv
│   └── VALE3 Dados Históricos.csv
├── src/                         # OBRIGATÓRIO
│   ├── __init__.py
│   ├── data_loader.py
│   ├── feature_engineering.py
│   ├── model_gru.py
│   └── utils.py
├── executar_modelo.py           # OBRIGATÓRIO
└── requirements.txt             # OBRIGATÓRIO
```

---

## 4. Executar o Modelo

### 4.1 Execução Padrão (5 runs, janela que obteve 90%)
```bash
python executar_modelo.py
```

### 4.2 Mais Execuções (para média mais confiável)
```bash
python executar_modelo.py --runs 10
```

### 4.3 Testar nos Últimos 30 Dias do Dataset
```bash
python executar_modelo.py --offset 0
```

### 4.4 Testar em Outra Janela
```bash
# offset = dias do final do dataset
python executar_modelo.py --offset 60   # 60-90 dias atrás
python executar_modelo.py --offset 90   # 90-120 dias atrás
```

---

## 5. Saída Esperada

```
======================================================================
 TECH CHALLENGE FASE 2 - PREVISÃO IBOVESPA
======================================================================
Data: 11/01/2026 12:00
Configuração: GRU 32 unidades
Execuções: 5

============================================================
 CARREGANDO DADOS
============================================================
  -> Carregando IBOV...
    [OK] 2482 registros carregados
  ...

============================================================
[CONFIG] CRIANDO FEATURES AVANÇADAS
============================================================
  -> Criando features para IBOV...
  ...
[OK] Total de features criadas: 294

============================================================
 TREINANDO MODELO (5 execuções)
============================================================
--- Execução 1/5 ---
   Acurácia: 80.00%
...

======================================================================
 RESULTADOS FINAIS
======================================================================
 Estatísticas (5 execuções):
   Média: 72.00%
   Máximo: 80.00%

 MELHOR RESULTADO:
   Acurácia: 80.00%
   Precision: 66.67%
   Recall: 66.67%
   F1-Score: 66.67%

 META DE 75% ATINGIDA! (80.00%)

 Modelo salvo em models/
```

---

## 6. Arquivos Gerados

Após a execução, serão criados em `models/`:

| Arquivo | Descrição |
|---------|-----------|
| `modelo_gru.keras` | Modelo treinado |
| `scaler.pkl` | Normalizador dos dados |
| `config.pkl` | Configurações usadas |

---

## 7. Usar Modelo Salvo

```python
from src.utils import load_model
from src.data_loader import load_all_data
from src.feature_engineering import FeatureEngineer, create_target

# Carregar modelo
model, scaler, config = load_model("models")

# Carregar novos dados
df = load_all_data("dados")
engineer = FeatureEngineer()
df = engineer.create_all_features(df)

# Preparar features
feature_cols = [c for c in df.columns if c not in ['Data', 'Target']]
X_new = df[feature_cols].values[-30:]  # Últimos 30 dias

# Normalizar
X_new_scaled = scaler.transform(X_new)

# Prever
from src.model_gru import predict
predictions, probabilities = predict(model, X_new_scaled, config)

print(f"Previsões: {predictions}")
print(f"Probabilidades: {probabilities}")
```

---

## 8. Troubleshooting

### Erro: "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### Erro: "FileNotFoundError" nos dados
- Verifique se a pasta `dados/` existe
- Verifique se os arquivos CSV estão na pasta

### Erro: "CUDA/GPU"
- O modelo funciona sem GPU
- Para desabilitar GPU: `export CUDA_VISIBLE_DEVICES=-1`

### Resultados diferentes
- Normal devido à aleatoriedade das redes neurais
- Execute múltiplas vezes (`--runs 10`)
- Use seeds fixas para reprodutibilidade exata

---

## 9. Dicas para Melhores Resultados

1. **Execute múltiplas vezes**: A média é mais confiável
2. **Teste diferentes janelas**: `--offset 0, 60, 90, 365`
3. **Use o modelo salvo**: Evita retreinar
4. **Monitore overfitting**: Compare treino vs validação

---

## 10. Contato

Em caso de dúvidas sobre a reprodução dos resultados, consulte:
- `docs/METODOLOGIA.md` - Detalhes técnicos
- `docs/RELATORIO_FINAL.md` - Resultados completos
