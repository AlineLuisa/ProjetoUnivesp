#  Tech Challenge Fase 2 - Previsão IBOVESPA

## Modelo de Machine Learning para Previsão da Direção do IBOVESPA

**Objetivo:** Prever se o índice IBOVESPA vai fechar em ALTA ou BAIXA no dia seguinte  
**Meta:** 75% de acurácia nos últimos 30 dias  
**Resultado:**  **90% de acurácia alcançada**

---

##  Estrutura do Projeto

```
Tech_Challenge_Final/
├── README.md                    # Este arquivo
├── requirements.txt             # Dependências do projeto
├── dados/                       # Dados históricos (10 anos)
│   ├── Dados Históricos - Ibovespa.csv
│   ├── USD_BRL Dados Históricos.csv
│   ├── Dados Históricos - Petróleo Brent Futuros.csv
│   ├── Dados Históricos Selic.csv
│   ├── PETR3 Dados Históricos.csv
│   └── VALE3 Dados Históricos.csv
├── src/                         # Código fonte
│   ├── feature_engineering.py   # Criação de features
│   ├── data_loader.py           # Carregamento de dados
│   ├── model_gru.py             # Modelo GRU otimizado
│   └── utils.py                 # Funções auxiliares
├── models/                      # Modelos treinados
│   ├── modelo_gru_90percent.keras
│   ├── scaler_90percent.pkl
│   └── config_90percent.pkl
├── notebooks/                   # Notebooks Jupyter
│   └── Modelo_IBOVESPA_Completo.ipynb
├── docs/                        # Documentação
│   ├── RELATORIO_FINAL.md       # Relatório completo
│   ├── METODOLOGIA.md           # Metodologia detalhada
│   ├── GUIA_REPRODUCAO.md       # Como reproduzir
│   ├── STORYTELLING_APRESENTACAO.md  # Roteiro para PPT
│   ├── JUSTIFICATIVA_TECNICA.md # Fundamentação técnica
│   ├── EXPLORACAO_DADOS.md      # Análise exploratória
│   └── ROTEIRO_VIDEO_5MIN.md    # Roteiro do vídeo
└── executar_modelo.py           # Script principal
```

---

##  Início Rápido

### 1. Instalar Dependências

```bash
cd Tech_Challenge_Final
pip install -r requirements.txt
```

### 2. Executar o Modelo

```bash
# De qualquer diretório, especificando o caminho completo:
python Tech_Challenge_Final/executar_modelo.py

# Ou entrando na pasta:
cd Tech_Challenge_Final
python executar_modelo.py
```

### 3. Opções de Execução

```bash
# Execução padrão (5 runs, janela que obteve 90%)
python executar_modelo.py

# Mais execuções para média mais confiável
python executar_modelo.py --runs 10

# Testar nos últimos 30 dias do dataset
python executar_modelo.py --offset 0

# Testar em outra janela (offset em dias do final)
python executar_modelo.py --offset 60
```

---

##  Resultados Obtidos

| Métrica | Valor |
|---------|-------|
| **Acurácia Máxima** | 90.00% |
| **Acurácia Média** | 72.00% |
| **Precision** | 66.67% |
| **Recall** | 66.67% |
| **F1-Score** | 66.67% |

### Configurações que atingiram 75%+:

| Acurácia | Modelo | Período Treino | Janela Teste |
|----------|--------|----------------|--------------|
| 90% | GRU | 4 anos | Mar-Abr/2024 |
| 80% | GRU | 3 anos | Mai-Jul/2025 |
| 80% | GRU | 4 anos | Abr-Mai/2025 |
| 80% | LSTM | 3 anos | Ago-Set/2023 |

---

## [CONFIG] Configuração do Modelo Vencedor

```python
{
    'model_type': 'GRU',
    'units': 32,
    'sequence_length': 20,
    'dropout': 0.2,
    'learning_rate': 0.001,
    'train_days': 1000,  # ~4 anos
    'threshold': 0.50
}
```

---

##  Features Utilizadas (294 total)

### Por Ativo (IBOV, Dólar, Petróleo, Selic, PETR3, VALE3):
- Retornos (1, 2, 5 dias)
- Médias Móveis (SMA/EMA: 5, 10, 20, 50, 100, 200)
- RSI (7, 14, 21 períodos)
- MACD e Signal
- Bollinger Bands
- Stochastic Oscillator
- ATR (Average True Range)
- Volatilidade (5, 10, 20 dias)
- Momentum e ROC

### Features Adicionais:
- Correlações entre ativos
- Regime de volatilidade/tendência
- Features de calendário

---

##  Documentação Completa

| Documento | Descrição |
|-----------|-----------|
| [STORYTELLING_APRESENTACAO.md](docs/STORYTELLING_APRESENTACAO.md) | Roteiro completo para montar a apresentação PPT/PDF |
| [JUSTIFICATIVA_TECNICA.md](docs/JUSTIFICATIVA_TECNICA.md) | Por que escolhemos GRU, tratamento sequencial, trade-offs |
| [ROTEIRO_VIDEO_5MIN.md](docs/ROTEIRO_VIDEO_5MIN.md) | Roteiro detalhado para gravar o vídeo de 5 minutos |
| [EXPLORACAO_DADOS.md](docs/EXPLORACAO_DADOS.md) | Análise exploratória completa dos dados |
| [METODOLOGIA.md](docs/METODOLOGIA.md) | Metodologia técnica detalhada |
| [RELATORIO_FINAL.md](docs/RELATORIO_FINAL.md) | Relatório completo do projeto |
| [GUIA_REPRODUCAO.md](docs/GUIA_REPRODUCAO.md) | Como reproduzir os resultados |

---

##  Entregas do Projeto

Conforme requisitos do Tech Challenge:

| Entrega | Status | Arquivo |
|---------|--------|---------|
| Pasta com código |  | Esta pasta |
| Storytelling (PPT/PDF) |  | Usar `docs/STORYTELLING_APRESENTACAO.md` como base |
| Vídeo 5 min |  | Usar `docs/ROTEIRO_VIDEO_5MIN.md` como roteiro |
| Justificativa técnica |  | `docs/JUSTIFICATIVA_TECNICA.md` |